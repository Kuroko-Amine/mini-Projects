let [S , M , H] = [0,0,0];
let displaytime = document.getElementById("Display");
let ti = null ;
function timer(){
    S++;
    if(S == 60){
        M++;
        S = 0;
        }
        if(M == 60){
            H++;
            M = 0;
        }
        let h = H < 10 ? "0" + H : H ;
        let m = M < 10 ? "0" + M : M ;
        let s = S < 10 ? "0" + S : S ;
        displaytime.innerHTML = h + ":" + m + ":" + s;
}

function watchST(){
    if(ti!=null){
        clearInterval(ti);
    }

    ti =setInterval(timer,1000);
}


function Resetw(){
    clearInterval(ti);
    H=0 ; 
    M=0 ;
    S=0 ;
    displaytime.innerHTML="00:00:00";
}

function Stopw(){
    clearInterval(ti);
}
