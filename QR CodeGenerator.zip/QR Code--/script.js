let imgBox = document.getElementById("imgBox");
let qrImg = document.getElementById("qrIMG");
let qrtxt = document.getElementById("qrTxt");
const But = document.getElementById("but");

But.addEventListener("click",()=>{
    if(qrtxt.value.length >0){
    qrImg.src = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data="+qrtxt.value;
   
    imgBox.classList.toggle("show-img");
    }else{
        alert("Please enter text to generate QR code");
    }

});



