let ei = document.getElementById("close");
let pas = document.getElementById("password");

ei.addEventListener("click",()=>{
    if( pas.type=="text"){
        pas.type="password";
        ei.src="eye-close.png";
    }else{
    pas.type="text";
    ei.src="eye-open.png";
    }
});