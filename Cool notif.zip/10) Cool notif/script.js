
let Tb = document.getElementById('toast-box');

let success='<i class="fa-solid fa-circle-check"></i> Successfully sent';
let error='<i class="fa-solid fa-circle-xmark"></i> Error sending';
let Invalid ='<i class="fa-solid fa-triangle-exclamation"></i> Invalid input';


function showT(e){
    let toast =document.createElement('div');
    toast.className = 'toast';
    toast.innerHTML = e;
    Tb.appendChild(toast);
    if(e.includes('Error')){
        toast.classList.add('Error')
      }
    
        if(e.includes('Invalid')){
            toast.classList.add('Invalid');
        }
        setTimeout(()=>{
            toast.remove();
        },5000);
        
}

