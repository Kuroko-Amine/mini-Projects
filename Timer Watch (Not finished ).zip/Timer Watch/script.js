let [S , M , H] = [0,0,0];
let displaytime = document.getElementById("Display");