const passwordB = document.getElementById("password");
const len =8 ;
const copied = document.getElementById("copiedText");


const upper="ABCDEFGHIJKLMNOPRSTUVWXYZ";
const lower="abcdefghijklmnopqrstuvwxyz";
const number="0123456789";
const specialchar="!@#$%^&*()_+"

const chars=upper + lower + number + specialchar ;
let password="";
function random(){
    
    for(let i=0;i<len;i++){
    password+= randomchar(chars);
    }

passwordB.value=password ;
}
function randomchar(chars) {
    return chars[Math.floor(Math.random() * chars.length)];
}

function copyP(){
    if(password==""){
        alert("Password is empty click on Generate");
    }else{
    passwordB.select();
    document.execCommand("copy");
    passwordB.blur();
    copied.style.display="inline";
    setTimeout(()=>{
        copied.style.display="none";
        },2000);
    }
}