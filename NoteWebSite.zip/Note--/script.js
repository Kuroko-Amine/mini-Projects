const notesCont = document.querySelector(".notes-container");
const CreatBtn= document.querySelector(".Btn");

let notes = document.querySelectorAll(".input-box");

function Save(){
    notesCont.innerHTML = localStorage.getItem("notes");
}

Save();



function UpdateS(){
    localStorage.setItem("notes",notesCont.innerHTML);
}



CreatBtn.addEventListener("click",()=>{
    let inputBox = document.createElement("p");
    let img = document.createElement("img");
    inputBox.appendChild(img) ;
    inputBox.className="input-box" ;
    inputBox.setAttribute("contenteditable" , "true");
    img.src="images/delete.png";
    notesCont.appendChild(inputBox);
    
});

notesCont.addEventListener("click", (e) => {
    if(e.target.tagName==="IMG"){
        e.target.parentElement.remove();
        UpdateS();
    }else if(e.target.tagName==="P"){
        notes = document.querySelectorAll(".input-box");
        notes.forEach(nt=>{
            nt.onkeyup = function(){
                UpdateS();
                }
        });
    }
});


document.addEventListener("keydown",event=>{
    if(event.key === "Enter"){
        document.execCommand("insertLineBreak");
        event.preventDefault();
    }
})