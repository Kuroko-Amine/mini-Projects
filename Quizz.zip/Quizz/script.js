const questions = [
    {
        question: "Quel est le boss final d'Elden Ring ?",
        answers: [
            { text: "Radagon de l'Ordre d'Or", correct: false },
            { text: "Maliketh, la Lame d'Ébène", correct: false },
            { text: "Elden Beast", correct: true },
            { text: "Rykard, Seigneur du Blasphème", correct: false },
        ]
    },
    {
        question: "Dans The Legend of Zelda: Breath of the Wild, quel est le nom du pouvoir qui permet de stopper le temps sur les objets ?",
        answers: [
            { text: "Cryonis", correct: false },
            { text: "Stasis", correct: true },
            { text: "Magnesis", correct: false },
            { text: "Revali’s Gale", correct: false },
        ]
    },
    {
        question: "Quel est le premier Pokémon du Pokédex National ?",
        answers: [
            { text: "Bulbizarre", correct: true },
            { text: "Pikachu", correct: false },
            { text: "Salamèche", correct: false },
            { text: "Roucool", correct: false },
        ]
    },
    {
        question: "Dans Dark Souls, que crie le marchand mort-vivant en mourant ?",
        answers: [
            { text: "Why you...!", correct: false },
            { text: "I'll be back!", correct: false },
            { text: "No... not like this...", correct: false },
            { text: "You’ll regret this!", correct: true },
        ]
    },
    {
        question: "Quelle ville sert de point central dans Red Dead Redemption 2 ?",
        answers: [
            { text: "Valentine", correct: false },
            { text: "Saint Denis", correct: true },
            { text: "Blackwater", correct: false },
            { text: "Armadillo", correct: false },
        ]
    },
    {
        question: "Quel est le vrai nom de l’agent 47 dans la série Hitman ?",
        answers: [
            { text: "John Smith", correct: false },
            { text: "David Bateson", correct: false },
            { text: "Timothy Olyphant", correct: false },
            { text: "Il n'a pas de vrai nom", correct: true },
        ]
    },
    {
        question: "Quel jeu a popularisé le genre Battle Royale ?",
        answers: [
            { text: "Fortnite", correct: false },
            { text: "Apex Legends", correct: false },
            { text: "PUBG", correct: true },
            { text: "Call of Duty: Warzone", correct: false },
        ]
    },
    {
        question: "Quel est le nom du premier niveau dans Super Mario 64 ?",
        answers: [
            { text: "Whomp's Fortress", correct: false },
            { text: "Cool, Cool Mountain", correct: false },
            { text: "Bob-omb Battlefield", correct: true },
            { text: "Big Boo's Haunt", correct: false },
        ]
    },
    {
        question: "Dans Skyrim, quelle faction permet au joueur de devenir un loup-garou ?",
        answers: [
            { text: "Les Lames", correct: false },
            { text: "La Confrérie Noire", correct: false },
            { text: "Les Compagnons", correct: true },
            { text: "Le Thalmor", correct: false },
        ]
    },
    {
        question: "Dans The Witcher 3, quel est le vrai nom de Ciri ?",
        answers: [
            { text: "Cirilla Fiona Elen Riannon", correct: true },
            { text: "Cirilla de Kaer Morhen", correct: false },
            { text: "Ciri Nilfgaard", correct: false },
            { text: "Cirilla von Attre", correct: false },
        ]
    }
];

const questionElemnt = document.getElementById("question");
const answerBtn = document.getElementById("answer-buttons");
const nextBtn = document.getElementById("next-btn");

let currentQstI=0 ;
let score = 0 ;

function Gameinit(){
    currentQstI=0 ;
    score = 0 ;
    nextBtn.innerHTML="Next";
    showQst();
}

function showQst(){
    reset();
    let currentqst = questions[currentQstI];
    let questionNo = currentQstI +1 ;
    questionElemnt.innerHTML = questionNo +". "+ currentqst.question ;
    currentqst.answers.forEach(answer =>{
        const button = document.createElement("button");
        button.innerHTML=answer.text ;
        button.classList.add("btn");
        answerBtn.appendChild(button) ;
        if(answer.correct){
            button.dataset.correct=answer.correct ;
        }
        button.addEventListener("click",checkAnswer);
    });
}

function reset(){
    nextBtn.style.display="none";
    while(answerBtn.firstChild){
        answerBtn.removeChild(answerBtn.firstChild);
    }
}

function checkAnswer(e){
    const selectedBtn = e.target ;
    const correct = selectedBtn.dataset.correct==="true" ;
    if(correct){
        selectedBtn.classList.add("correct");
        score++;
        
        }else{
            selectedBtn.classList.add("incorrect");
        }
        Array.from(answerBtn.children).forEach(x=>{
            if(x.dataset.correct==="true"){
                x.classList.add("correct");
                }
                x.disabled = true ;
        });
        nextBtn.style.display="block";

}

function handleNextBtn(){
    currentQstI++;
    if(currentQstI<questions.length){
        showQst();
        }else{
            showScore();
        }
}
function showScore(){
    reset();
    questionElemnt.innerHTML=`Ton score est de ${score} sur ${questions.length} !` ;
    nextBtn.innerHTML = "Play Again";
    nextBtn.style.display="block";
}

nextBtn.addEventListener("click" , ()=>{
    if(currentQstI<questions.length){
        handleNextBtn();
    }else{
        Gameinit();
    }
});

Gameinit();