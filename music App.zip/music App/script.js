let prog = document.getElementById('prog');
let ctrls = document.getElementById('ctrl');
let song = document.getElementById('song');

song.volume = 0.3 ;

song.addEventListener("loadedmetadata", () => {
    prog.max = song.duration;
    prog.value = song.currentTime;
});


song.addEventListener("timeupdate", () => {
    prog.value = song.currentTime;
});


function playP() {
    if (song.paused) {
        song.play();
        ctrls.classList.remove('fa-play');
        ctrls.classList.add('fa-pause');
    } else {
        song.pause();
        ctrls.classList.remove('fa-pause');
        ctrls.classList.add('fa-play');
    }
}


prog.addEventListener("input", () => {
    song.currentTime = prog.value;
});
